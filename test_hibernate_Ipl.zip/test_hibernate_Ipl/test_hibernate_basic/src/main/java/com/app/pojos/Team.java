package com.app.pojos;

import javax.persistence.*;

/*
#teams : id , name, abbrevation,owner,max_age,batting_avg,wickets_taken	
# table
create table teams (team_id int primary key auto_increment,name varchar(100),abbrevation varchar(10),
owner varchar(20),max_age int,
batting_avg double,wickets_taken int);
 */

@Entity
public class Team {

	@Id // primary key
	// to specify auto id generation using auto increament strategy
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment
	@Column(name = "id")
	private Integer id;// id should be serialzable if int is wrriten it will autobox it so make id
						// property explicitly serialzable (All wrapper classes are serialzable

	@Column(length = 100, unique = true)
	private String name;

	@Column(length = 10, unique = true)
	private String abbrevation;

	@Column(length = 20)
	private String owner;

	@Column(name = "max_age")
	private int maxAge;

	@Column(name = "batting_avg")
	private double battingAvg;

	@Column(name = "wickets_taken")
	private int wicketsTaken;

	public Team() {
		// TODO Auto-generated constructor stub
	}

	public Team(String name, String abbrevation, String owner, int maxAge, double battingAvg, int wicketsTaken) {
		this.name = name;
		this.abbrevation = abbrevation;
		this.owner = owner;
		this.maxAge = maxAge;
		this.battingAvg = battingAvg;
		this.wicketsTaken = wicketsTaken;
	}

	public Team(Integer id, String abbrevation) {
		super();
		this.id = id;
		this.abbrevation = abbrevation;
	}

	public Integer getId() {
		return id;
	}

	//you can decide which fields to show or hide
	@Override
	public String toString() {
		return "Teams [id=" + getId() + ", name=" + name + ", abbrevation=" + abbrevation + ", owner=" + owner + ", maxAge="
				+ maxAge + ", battingAvg=" + battingAvg + ", wicketsTaken=" + wicketsTaken + "]";
	}

	// All getters and settters are required by hibernate for reflection
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbbrevation() {
		return abbrevation;
	}

	public void setAbbrevation(String abbrevation) {
		this.abbrevation = abbrevation;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public double getBattingAvg() {
		return battingAvg;
	}

	public void setBattingAvg(double battingAvg) {
		this.battingAvg = battingAvg;
	}

	public int getWicketsTaken() {
		return wicketsTaken;
	}

	public void setWicketsTaken(int wicketsTaken) {
		this.wicketsTaken = wicketsTaken;
	}

}
