package com.app.tester;

import org.hibernate.*;

import com.app.dao.TeamDaoImpl;
import com.app.pojos.Team;

import static com.app.utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class GetTeamIdNAbbDetails {

	public static void main(String[] args) {
		// get SF from utils
		try (SessionFactory sf = getFactory()) {
			// create team dao
			TeamDaoImpl teamDao = new TeamDaoImpl();
			teamDao.getTeamIdNAbbreviation().forEach(e -> System.out.println(e.getId()+" "+e.getAbbrevation()));
		} // sf.close --> Hibernate will auto clean up DBCP
		catch (Exception e) {
			// TODO: handle exception

			e.printStackTrace();
		}

	}

}
