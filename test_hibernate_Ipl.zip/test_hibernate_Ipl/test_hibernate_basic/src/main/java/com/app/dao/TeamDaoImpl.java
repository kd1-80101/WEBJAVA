

package com.app.dao;

import com.app.pojos.Team;
import org.hibernate.*;
import static com.app.utils.HibernateUtils.getFactory;

import java.io.Serializable;
import java.util.List;

public class TeamDaoImpl implements TeamDao {
	@Override
	public String updateMaxAgeNBattingAvgByTeamName(String teamName, Integer maxAge, Integer battingAvg) {
		String msg = "Update Failed !!!!!!";
		String jpql = "select t from Team t where t.name =:tName";
		Team tTeam = null;
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			tTeam = session.createQuery(jpql, Team.class).setParameter("tName", teamName).getSingleResult();
			tTeam.setMaxAge(tTeam.getMaxAge() + maxAge);
			tTeam.setBattingAvg(tTeam.getBattingAvg() + battingAvg);
			msg = "Updated " + tTeam.getName() + "MaxAge to :" + tTeam.getMaxAge() + " and Batting Avg to :"
					+ tTeam.getBattingAvg();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return msg;
	}

	@Override
	public String addNewTeam(Team newTeam) {
		String msg = "Adding team Failed";

		// 1.get session from SF
		Session session = getFactory().getCurrentSession();

		// 2.begin tx
		Transaction tx = session.beginTransaction();

		// 3.try -save team details, commit
		try {
			Serializable teamId = session.save(newTeam);
			tx.commit();
			msg = "Added new team Successfully with id :" + teamId;
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		// catch :runtime exc : rollback tx throw e

		return msg;
	}

	@Override
	public String deleteTeamDetails(Integer teamId) {
		String msg = "delete failed !!!!";
		Team tTeam = null;
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			tTeam = session.get(Team.class, teamId);
			if (tTeam != null) {
				session.delete(tTeam);
			}
			tx.commit();
			msg = "Deleted " + tTeam.getName() + "'s Team Details Successfully";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return msg;
	}

	@Override
	public Team getTeamById(Integer teamId) {
		Team newTeam = null;
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			newTeam = session.get(Team.class, teamId);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return newTeam;
	}

	@Override
	public List<Team> getTeamIdNAbbreviation() {
		List<Team> teams = null;
		String jpql = "select new com.app.pojos.Team(id,abbrevation) from Team t";
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return teams;
	}

	@Override
	public List<Team> getTeamsDetailsWithMaxAgeNMinWickets(Integer maxAge, Integer minWickets) {
		List<Team> teams = null;
		String jpql = "select t from Team t where t.maxAge <:mAge and t.wicketsTaken > :mWkt";
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).setParameter("mAge", maxAge).setParameter("mWkt", minWickets)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return teams;
	}

}
