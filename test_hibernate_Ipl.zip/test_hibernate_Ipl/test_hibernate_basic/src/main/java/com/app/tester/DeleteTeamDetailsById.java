package com.app.tester;

import org.hibernate.*;

import com.app.dao.TeamDaoImpl;
import com.app.pojos.Team;

import static com.app.utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class DeleteTeamDetailsById {

	public static void main(String[] args) {
		// get SF from utils
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			// create team dao
			TeamDaoImpl teamDao = new TeamDaoImpl();
			System.out.println("Enter the teamName:  maxAge:  battingAvg:  values to update ::");
			System.out.println(teamDao.updateMaxAgeNBattingAvgByTeamName(sc.next(), sc.nextInt(), sc.nextInt()));
		} // sf.close --> Hibernate will auto clean up DBCP
		catch (Exception e) {
			// TODO: handle exception

			e.printStackTrace();
		}

	}

}
