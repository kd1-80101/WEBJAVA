
package com.app.tester;

import org.hibernate.*;

import com.app.dao.TeamDaoImpl;
import com.app.pojos.Team;

import static com.app.utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class GetTeamDetailsWithMAxAgeNMinWickets {

	public static void main(String[] args) {
		// get SF from utils
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			// create team dao
			TeamDaoImpl teamDao = new TeamDaoImpl();
			System.out.println("enter the max age and min wickets");
			teamDao.getTeamsDetailsWithMaxAgeNMinWickets(sc.nextInt(), sc.nextInt()).forEach(System.out::println);
		} // sf.close --> Hibernate will auto clean up DBCP
		catch (Exception e) {
			// TODO: handle exception

			e.printStackTrace();
		}

	}

}
