package com.app.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;

import com.app.pojos.Team;

public interface TeamDao {
	// add method to add new team
	String addNewTeam(Team newTeam);

	// Display team id n abbreviation of all the teams
	List<Team> getTeamIdNAbbreviation();

	// Display team details , of a team by it's id
	Team getTeamById(Integer teamId);

	// Display all those teams who need , player's max age < specific age n min no
	// of wickets taken > specified wickets
	List<Team> getTeamsDetailsWithMaxAgeNMinWickets(Integer maxAge, Integer minWickets);

	// Update max age n batting avg requirement of a specific team by it's name
	// (team name is unique)
	String updateMaxAgeNBattingAvgByTeamName(String teamName, Integer maxAge, Integer battingAvg);

	// Delete team details
	String deleteTeamDetails(Integer teamId);
}
