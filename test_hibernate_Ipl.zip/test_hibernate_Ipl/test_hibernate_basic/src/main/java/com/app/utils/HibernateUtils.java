package com.app.utils;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class HibernateUtils {
	private static SessionFactory factory;
	// static block to create singleton SF
	// configuration--> configure--> buildSessionFactory
	static {
		// build SF
		factory = new Configuration()// empty config created
				.configure()// reads hibernste config xml file n populates the config object
				.buildSessionFactory();// builds instance of SF from the populated(filled up) config
		System.out.println("Sf created");
	}
	public static SessionFactory getFactory() {
		return factory;
	}
	


}
