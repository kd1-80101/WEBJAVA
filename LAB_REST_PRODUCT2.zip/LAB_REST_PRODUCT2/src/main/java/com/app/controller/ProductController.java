package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ProductDTO;
import com.app.dto.UpdateProductDTO;
import com.app.entities.Product;
import com.app.service.productService;

@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductController {
	@Autowired
	private productService prodService;

	public ProductController() {
		System.out.println("in ctor of prod controller");
	}

	@RequestMapping
	private List<Product> getAllProducts() {

		return prodService.getAllProducts();
	}

	@PostMapping("/{catId}")
	private ProductDTO addNewProduct(@RequestBody @Valid ProductDTO prod, @PathVariable Long catId) {
		return prodService.addNewProducts(prod, catId);
	}

	@GetMapping("/{prodId}")
	private Product getProductById(@PathVariable Long prodId) {

		return prodService.getProdDetailsById(prodId);
	}

	@GetMapping("/cat/{catId}")
	private List<ProductDTO> getProductByCategory(@PathVariable Long catId) {

		return prodService.getProductByCategory(catId);
	}

	@PutMapping
	private Product updateProduct(@RequestBody Product prod) {
		return prodService.updateProduct(prod);
	}

	@DeleteMapping("/{prodId}")
	private String deleteproductDetails(@PathVariable Long prodId) {

		return prodService.deleteById(prodId);
	}

	@PutMapping("/{prodId}")
	private ProductDTO updateProductPrice(@RequestBody UpdateProductDTO prod) {
		return prodService.updateProductPrice(prod);
	}

}
