package com.app.service;

import java.util.List;

import com.app.dto.ProductDTO;
import com.app.dto.UpdateProductDTO;
import com.app.entities.Product;

public interface productService {

	List<Product> getAllProducts();

	ProductDTO addNewProducts(ProductDTO prod, Long catId);

	Product getProdDetailsById(Long prodId);

	Product updateProduct(Product prod);

	String deleteById(Long prodId);

	List<ProductDTO> getProductByCategory(Long catId);

	ProductDTO updateProductPrice(UpdateProductDTO prod);
}
