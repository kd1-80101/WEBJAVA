package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.CustomException;
import com.app.dao.CategoryDao;
import com.app.dao.productDao;
import com.app.dto.ProductDTO;
import com.app.dto.UpdateProductDTO;
import com.app.entities.Category;
import com.app.entities.Product;

@Service
@Transactional
public class ProductServiceImpl implements productService {

	@Autowired
	private productDao prodDao;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CategoryDao cdao;

	@Override
	public List<Product> getAllProducts() {
		System.out.println("in getallproducts");
		return prodDao.findAll();
	}

	@Override
	public Product getProdDetailsById(Long prodId) {
		System.out.println("in getProdDetailsById" + prodId);// TODO Auto-generated method stub
		return prodDao.findById(prodId).orElseThrow(() -> new CustomException("Invalid id"));
	}

	@Override
	public String deleteById(Long prodId) {
		if (prodDao.existsById(prodId)) {
			prodDao.deleteById(prodId);
			return "deleted details";
		}
		throw new CustomException("Invalid prod id,Failed to delete");
	}

	@Override

	public Product updateProduct(Product prod) {
		if (prodDao.existsById(prod.getId())) {
			prodDao.save(prod);
			return prod;
		}
		throw new CustomException("Invalid prod id,Failed to update");
	}

	@Override
	public ProductDTO updateProductPrice(UpdateProductDTO prod) {
		Product product = prodDao.findById(prod.getProId()).orElseThrow(() -> new CustomException("Invalid prod id"));
		product.setPrice(prod.getPrice());
		return mapper.map(prodDao.save(product), ProductDTO.class);
	}

	@Override
	public ProductDTO addNewProducts(ProductDTO prod, Long catId) {
		System.out.println("in add new prod" + prod);
		Category tempCat = cdao.findById(catId).orElseThrow(() -> new CustomException("Invalid  cat id"));
		prodDao.findByName(prod.getName()).orElseThrow(() -> new CustomException("duplicate name"));
		Product newProduct = mapper.map(prod, Product.class);
		newProduct.setProductCategory(tempCat);// transient
		return mapper.map(prodDao.save(newProduct)/* persistent */, ProductDTO.class);
	}

	@Override
	public List<ProductDTO> getProductByCategory(Long catId) {

		cdao.findById(catId).orElseThrow(() -> new CustomException("Invalid  cat id"));
		return prodDao.findByProductCategoryId(catId).stream().map(p -> mapper.map(p, ProductDTO.class))
				.collect(Collectors.toList());
	}
}
