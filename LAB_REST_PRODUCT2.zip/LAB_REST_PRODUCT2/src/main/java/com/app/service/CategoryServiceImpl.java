package com.app.service;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.CategoryDao;
import com.app.dto.CategoryDTO;
import com.app.entities.Category;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao cdao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public CategoryDTO addNewCategoryDetails(CategoryDTO cdto) {
		Category newCat = cdao.save(mapper.map(cdto, Category.class));
		return mapper.map(newCat, CategoryDTO.class);
	}

}
