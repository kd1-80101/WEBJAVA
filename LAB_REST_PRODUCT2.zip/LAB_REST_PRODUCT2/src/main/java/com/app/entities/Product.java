package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//id (from BaseEntity : Long) , name (unique) , description ,category(enum) , price , available stock(int),expiryDate:LocalDate
@Entity
@Table(name = "products")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Product extends BaseEntity {
	@Column(length = 40, unique = true)
	private String name;
	@Column(length = 60)
	private String description;
	private double price;
	@Column(name = "available_stock")
	private int stock;
	@Column(name = "expiryDate")
	private LocalDate date;
	@ManyToOne
	@JoinColumn(nullable = false)
	private Category productCategory;

}
