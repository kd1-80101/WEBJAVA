package com.app.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateProductDTO {
	@NotNull
	private long proId;
	@NotNull
	@Max(value = 500)
	private Double price;
}
