package com.app.dto;

import java.time.LocalDate;

import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDTO {
	@JsonProperty(access = Access.READ_ONLY)
	private Long id;
	@NotBlank
	private String name;
	@NotBlank
	private String description;
	@Max(value = 500)
	@NotNull
	private double price;
	@NotNull
	private int stock;
	@NotNull
	@Future
	private LocalDate date;
}

/*
 * category id can't be null product name must be supplied product price < 500
 * expiry date must be in future product name must be unique.(not duplicate)
 */
