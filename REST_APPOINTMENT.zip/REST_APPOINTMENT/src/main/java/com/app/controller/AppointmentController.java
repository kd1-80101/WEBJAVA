package com.app.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AppointmentDTO;
import com.app.service.AppointmentService;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

	@Autowired
	private AppointmentService appService;
	
	@PostMapping 
	private AppointmentDTO bookAppointment(@RequestBody @Valid AppointmentDTO appt)  
	{
	return appService.bookNewAppointment(appt);	
	}

//		Endpoint: GET /appointments/{user}/upcoming
	@GetMapping("/{userId}")
	private List<AppointmentDTO> getAppointmentDetailsForPatient(@PathVariable @NotNull Long userId){
		return appService.getAppointmentDetailsForPatient(userId);
		
	}
 
}
