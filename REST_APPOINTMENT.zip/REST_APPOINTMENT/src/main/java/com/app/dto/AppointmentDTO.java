package com.app.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AppointmentDTO {

	@NotNull
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long doc_id;
	@NotNull
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long pat_id;
	@NotBlank
	private String description;
	@NotNull
	@Future
	private LocalDateTime appTime;
	@JsonProperty(access = Access.READ_ONLY)
	private Long id;
	@JsonProperty(access = Access.READ_ONLY)
	private String status;

}
