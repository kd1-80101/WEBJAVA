package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.ApiException;
import com.app.dao.AppointmentDao;
import com.app.dao.DoctorDao;
import com.app.dao.PatientDao;
import com.app.dto.AppointmentDTO;
import com.app.entities.Appointment;
import com.app.entities.Doctor;
import com.app.entities.Patient;

@Service
@Transactional
public class ApointmentServiceImpl implements AppointmentService {

	@Autowired
	private DoctorDao docDao;

	@Autowired
	private PatientDao patDao;

	@Autowired
	private AppointmentDao appDao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public AppointmentDTO bookNewAppointment(AppointmentDTO appt) {
		Doctor doctor = docDao.findById(appt.getDoc_id()).orElseThrow(() -> new ApiException("Invalid doctor id"));
		Patient patient = patDao.findById(appt.getPat_id()).orElseThrow(() -> new ApiException("Invalid patient id"));
		Appointment docA = appDao.findByAppTimeAndDoctorId(appt.getAppTime(), appt.getDoc_id());
		Appointment patA = appDao.findByAppTimeAndPatientId(appt.getAppTime(), appt.getPat_id());
		Appointment newApp = mapper.map(appt, Appointment.class);
		newApp.setDoctor(doctor);
		newApp.setPatient(patient);
		System.out.println(docA + "   " + patA + " " + appt);
		String msg = "Failed";
		if (patA == null) {
			if (docA == null) {
				Appointment savedAppointment = appDao.save(newApp);
				AppointmentDTO respDTO = mapper.map(savedAppointment, AppointmentDTO.class);
				respDTO.setStatus("Successsfully saved appointment");
				return respDTO;
			} else
				msg = "Failed to set Doctor is not Available";
		} else
			msg = "Failed to set Patient is not Available";
		appt.setStatus(msg);
		return appt;

	}

	@Override
	public List<AppointmentDTO> getAppointmentDetailsForPatient(Long userId) {

		return appDao.findAllByPatientId(userId).stream().map(a->mapper.map(a, AppointmentDTO.class)).collect(Collectors.toList());
		
	}

}
