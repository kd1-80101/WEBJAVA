package com.app.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.app.dto.AppointmentDTO;

public interface AppointmentService {

	AppointmentDTO bookNewAppointment(AppointmentDTO appt);

	List<AppointmentDTO> getAppointmentDetailsForPatient(@NotNull Long userId);

}
