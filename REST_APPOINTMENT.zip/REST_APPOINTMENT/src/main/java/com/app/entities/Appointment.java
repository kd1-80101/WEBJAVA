package com.app.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "appointments")
public class Appointment extends BaseEntity	 {

	@Column(length = 50)
	private String description;

	@Column(name = "appointment_schedule")
	private LocalDateTime appTime;

	@ManyToOne
	@JoinColumn(name = "doc_id")
	private Doctor doctor;

	@ManyToOne
	@JoinColumn(name = "pat_id")
	private Patient patient;

}
