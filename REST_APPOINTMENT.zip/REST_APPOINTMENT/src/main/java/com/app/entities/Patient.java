package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "patients")
public class Patient extends BaseEntity {
	@Column(name="first_name",length = 30)
	private String fName;
	@Column(name="last_name",length = 30)
	private String lName;
	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	private Gender gender;
}
