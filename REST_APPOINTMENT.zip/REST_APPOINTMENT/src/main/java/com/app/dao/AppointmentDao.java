package com.app.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Appointment;

public interface AppointmentDao extends JpaRepository<Appointment, Long> {

	//Appointment findByDTimeAndDoctorId(LocalDateTime dTime, Long doc_id);
	Appointment findByAppTimeAndDoctorId(LocalDateTime tm,Long docId);

	Appointment findByAppTimeAndPatientId(LocalDateTime dTime, Long pat_id);

	List<Appointment> findAllByPatientId(Long userId);

}
