package com.app.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.app.entities.Company;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CarDTO {
	@NotBlank
	private String vehicalName;
	private Company company;
	@NotBlank
	private String vehicalType;
	@NotNull
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long userId;
	@JsonProperty(access = Access.READ_ONLY)
	private Long id;
	@NotBlank
	@Length(max = 10)
	private String vehicalNumber;
}
