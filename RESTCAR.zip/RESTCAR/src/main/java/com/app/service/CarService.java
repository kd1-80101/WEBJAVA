package com.app.service;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.app.dto.CarDTO;

public interface CarService {

	List<CarDTO> getAllCarsDetails(@NotNull String userName);

	CarDTO addNewVehicalDetails(@Valid CarDTO vehical);

	
	
}
