package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.CarDao;
import com.app.dao.UserDao;
import com.app.dto.CarDTO;
import com.app.entities.Car;
import com.app.entities.User;

@Service
@Transactional
public class CarServiceImpl implements CarService {
	@Autowired
	private UserDao userDao;
	@Autowired
	private CarDao carDao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public CarDTO addNewVehicalDetails(@Valid CarDTO vehical) {
		User owner = userDao.findById(vehical.getUserId())
				.orElseThrow(() -> new ResourceNotFoundException("user id invalid"));
		Car car = mapper.map(vehical, Car.class);
		car.setUser(owner);
		return mapper.map(carDao.save(car), CarDTO.class);
	}

	@Override
	public List<CarDTO> getAllCarsDetails(String userName) {
		User owner = userDao.findByUserName(userName).orElseThrow(() -> new ResourceNotFoundException("Invalid user id"));
		return carDao.findAllByUserId(owner.getId()).stream().map(c -> mapper.map(c, CarDTO.class))
				.collect(Collectors.toList());
	}

}
