package com.app.entities;

public enum Company {
HONDA,BMW,SUZUKI,HERO
}
