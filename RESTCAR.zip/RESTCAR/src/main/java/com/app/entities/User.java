package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "users")
@Getter
@Setter
public class User extends BaseEntity {
	@Column(length = 20)
	private String userName;
	@Column(length = 30)
	private String email;
	@Column(length = 20)
	private String password;
	@Column(length = 20)
	private String city;
	private Long mobNo;
}
