package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "cars")
@Getter
@Setter
@ToString

public class Car extends BaseEntity {
	@Column(name = "vehical_name", length = 20)
	private String vehicalName;
	@Enumerated(EnumType.STRING)
	private Company company;
	@Column(name = "vehical_type")
	private String vehicalType;
	@Column(name = "vehical_number")
	private String vehicalNumber;
	@ManyToOne
	private User user;
}
