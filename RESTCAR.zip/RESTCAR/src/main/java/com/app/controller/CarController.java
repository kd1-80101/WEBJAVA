package com.app.controller;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.CarDTO;
import com.app.service.CarService;

@RestController
@RequestMapping("/vehicle")
public class CarController {

	@Autowired
	private CarService carService;

	@GetMapping("/{userName}")
	public ResponseEntity<?> getAllVehicalDetails(@PathVariable @NotNull String userName) {
		return ResponseEntity.status(HttpStatus.OK).body(carService.getAllCarsDetails(userName));
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addNewVehicalDetails(@RequestBody @Valid CarDTO vehical){
		return ResponseEntity.status(HttpStatus.CREATED).body(carService.addNewVehicalDetails(vehical));
	}
}
