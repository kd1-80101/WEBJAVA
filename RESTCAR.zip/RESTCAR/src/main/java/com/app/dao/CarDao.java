package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Car;

public interface CarDao extends JpaRepository<Car, Long> {

	List<Car> findAllByUserId(Long userId);

}
