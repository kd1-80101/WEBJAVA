package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.DepartmentDao;
import com.app.pojos.Department;

@Service // mandatory class level anno to tell SC =>
			// => following is a spring bean => containing B.L.
@Transactional // mandatory anno to tell SC =>
//=> manage DB Trans automatically
public class DepartmentServiceImpl implements DepartmentService {
//depcy : dao layer i/f
	@Autowired
	private DepartmentDao deptDao;

	@Override
	public List<Department> getAllDepartments() {
		return deptDao.getAllDepartments();
	}

}
