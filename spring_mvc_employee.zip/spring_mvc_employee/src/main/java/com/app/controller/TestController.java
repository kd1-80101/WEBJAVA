package com.app.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller // mandatory
@RequestMapping("/test") // optional but recommended for the reusable base pattern
public class TestController {

	public TestController() {
		System.out.println("In TestController ctor");
	}

	// URL : http://host:port/ctx/test/test1
	@GetMapping("/test1") // == @RequestMapping(method=GET)
	// in HandlerMapping Bean
	// KEY=
	// VALUE = com.app.controller
	public ModelAndView testModelAndView() {
		System.out.println("In testModelAndView ");
		// o.s.w.s.ModelAndView(String LVN, String modelAttribute,ObjectmodelAtribute
		// value)
		return new ModelAndView("/test/test1", "server_ts", LocalDateTime.now());
	}
	/*
	 * Handler returns MnV--> D.S
	 *  D.S --> LVN --> V.R --> AVN : /WEB-INF/views/test/test1.jsp 
	 *  D.S--> adds model attrs (results) under request
	 *  scope forwards the clnt to the JSP based view layer
	 */
}
