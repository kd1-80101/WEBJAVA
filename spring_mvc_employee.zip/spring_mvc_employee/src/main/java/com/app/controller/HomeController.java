package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	public HomeController() {
		System.out.println("in HomeController" + getClass());
	}

	@RequestMapping("/")
	public String HomePageController() {
		System.out.println("in HomePageController()");
		return "/index";// handler -->LVN -->D.S-->V.R-->AVN
		// AVN : ?WEB-INF/views/index.jsp-->
		// D.S forwards the clint to the JSP
	}
}
