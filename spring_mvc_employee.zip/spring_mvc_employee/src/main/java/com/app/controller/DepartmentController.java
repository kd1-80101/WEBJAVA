package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.app.service.DepartmentService;

@Controller
@RequestMapping("/departments")
public class DepartmentController {
//depcy ; service layer i/f
	@Autowired
	private DepartmentService deptService;

	public DepartmentController() {
		System.out.println("in def ctor if DepartmentController ");
	}

	// url : http://host:port/ctx_path/departments/list
	// method :GET
	@GetMapping("/list")
	public ModelAndView listAllDepartments() {
		System.out.println("in all departs");
		// o.s.w.s.ModelAndView(String LVN, String modelAttribute,ObjectmodelAtribute
		// value)
		return new ModelAndView("/departments/list", "dept_list", deptService.getAllDepartments());
	}
	/*
	 * Handler --> MnV --> D.S D.S--> LVN -->AVN :WEB-INF/views/departments/list.jsp
	 * D.S stores model attrs under : request scope (current req only) forwards the
	 * request to the JSP based view layer
	 */
}
