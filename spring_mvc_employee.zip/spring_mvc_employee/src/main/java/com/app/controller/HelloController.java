package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // mandatory anno to tell SC ,
//following is spring bean, having req handling methods
//singleton n eager
public class HelloController {

	public HelloController() {
		System.out.println("in ctor of" + getClass()); // TODO Auto-generated constructor stub
	}

	// add req handling method to display welcome msg
	@RequestMapping("/hello") // mandatory method lelvel anno
	// to interscept any HTTP req(get|post|put...)
	public String sayHello() {
		System.out.println("in say hello");
		// returns LVN(Logical View Name) to D.S (DispatcherServlet)
		//--> to be reolved by V.R(ViewReslover)
		return "/welcome";//AVN : /WEB-INF/
	}
}
