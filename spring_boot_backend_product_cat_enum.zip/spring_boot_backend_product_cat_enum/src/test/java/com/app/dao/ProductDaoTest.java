package com.app.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.app.pojos.Category;
import com.app.pojos.Product;

@DataJpaTest // => Spring boot test frmwork will scan entities n dao
@AutoConfigureTestDatabase(replace = Replace.NONE) // => use regulate DB
@Rollback(false)
public class ProductDaoTest {
	@Autowired
	private productDao prodDao;

	@Test
	void testProdSaveTest() {
		List<Product> list = List.of(
				new Product("REALME 4K", "REALME TV TESTING", 99999, 2323, LocalDate.parse("2024-12-12"),
						Category.television),
				new Product("ADV JAVA", "JAVA BOOK TESTING", 99, 23, LocalDate.parse("2022-12-12"), Category.book),
				new Product("LENOVO LAPTOP", "LENOVO LAPTOP TESTING", 44999, 23, LocalDate.parse("2024-12-12"),
						Category.laptop),
				new Product("DBT", "DBT BOOK TESTING", 109, 2323, LocalDate.parse("2024-12-12"), Category.book),
				new Product("LAVA GALAXY", "SAMSUNG SMARTPHONE TESTING", 9999, 1123, LocalDate.parse("2024-12-12"),
						Category.smartphone));
		List<Product> list2 = prodDao.saveAll(list);
		assertEquals(5, list2.size());
	}
}
