package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.service.productService;

@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductController {
	@Autowired
	private productService prodService;

	public ProductController() {
		System.out.println("in ctor of prod controller");
	}

	@RequestMapping
	private List<Product> getAllProducts() {

		return prodService.getAllProducts();
	}

	@PostMapping
	private Product addNewProduct(@RequestBody Product prod) {
		return prodService.addNewProducts(prod);
	}

	@GetMapping("/{prodId}")
	private Product getProductById(@PathVariable Long prodId) {

		return prodService.getProdDetailsById(prodId);
	}

	@GetMapping("/category/{cat}")
	private List<Product> getProductsByCategory(@PathVariable Category cat) {

		return prodService.getProdDetailsByCategory(cat);
	}

	@PutMapping
	private Product updateProduct(@RequestBody Product prod) {
		return prodService.updateProduct(prod);
	}

	@DeleteMapping("/{prodId}")
	private String deleteproductDetails(@PathVariable Long prodId) {

		return prodService.deleteById(prodId);
	}

}
