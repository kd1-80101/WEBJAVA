package com.app.pojos;

public enum Category {

	smartphone, television, book, laptop
}
