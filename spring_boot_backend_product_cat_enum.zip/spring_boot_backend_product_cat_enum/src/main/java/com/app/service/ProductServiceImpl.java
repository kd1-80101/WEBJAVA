package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.productDao;
import com.app.exception.CustomException;
import com.app.pojos.Category;
import com.app.pojos.Product;

@Service
@Transactional
public class ProductServiceImpl implements productService {

	@Autowired
	private productDao prodDao;

	@Override
	public List<Product> getAllProducts() {
		System.out.println("in getallproducts");
		return prodDao.findAll();
	}

	@Override
	public Product getProdDetailsById(Long prodId) {
		System.out.println("in getProdDetailsById" + prodId);// TODO Auto-generated method stub
		return prodDao.findById(prodId).orElseThrow(() -> new CustomException("Invalid id"));
	}

	@Override
	public List<Product> getProdDetailsByCategory(Category cat) {
		return prodDao.findByCategory(cat);
	}

	@Override
	public String deleteById(Long prodId) {
		if (prodDao.existsById(prodId)) {
			prodDao.deleteById(prodId);
			return "deleted details";
		}
		throw new CustomException("Invalid prod id,Failed to delete");
	}

	@Override
	public Product updateProduct(Product prod) {
		if (prodDao.existsById(prod.getId())) {
			prodDao.save(prod);
			return prod;
		}
		throw new CustomException("Invalid prod id,Failed to update");
	}

	@Override
	public Product addNewProducts(Product prod) {
		System.out.println("in add new prod" + prod);
		return prodDao.save(prod);
	}
}
