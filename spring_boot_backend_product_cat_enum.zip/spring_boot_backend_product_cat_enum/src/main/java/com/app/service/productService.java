package com.app.service;

import java.util.List;

import com.app.pojos.Category;
import com.app.pojos.Product;

public interface productService {

	List<Product> getAllProducts();

	Product addNewProducts(Product prod);

	Product getProdDetailsById(Long prodId);

	List<Product> getProdDetailsByCategory(Category cat);

	Product updateProduct(Product prod);

	String deleteById(Long prodId);
}
