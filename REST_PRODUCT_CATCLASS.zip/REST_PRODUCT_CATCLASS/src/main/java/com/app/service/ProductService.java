package com.app.service;

import java.util.List;

import com.app.dto.ProductDTO;

public interface ProductService {

	ProductDTO addProducts(ProductDTO prod);

	List<ProductDTO> getAllProducts();

}
