package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CategoryDao;
import com.app.dto.CategoryDTO;
import com.app.entity.Category;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao catDao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public List<CategoryDTO> getAllCategories() {
		return catDao.findAll().stream().map(c -> mapper.map(c, CategoryDTO.class)).collect(Collectors.toList());

	}

	@Override
	public CategoryDTO addNewCategory(CategoryDTO cat) {
		return mapper.map(catDao.save(mapper.map(cat, Category.class)), CategoryDTO.class);
	}
}
