package com.app.service;

import java.util.List;

import com.app.dto.CategoryDTO;
import com.app.entity.Category;

public interface CategoryService {

	List<CategoryDTO> getAllCategories();

	CategoryDTO addNewCategory(CategoryDTO cat);

}
