package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CategoryDao;
import com.app.dao.ProductDao;
import com.app.dto.ProductDTO;
import com.app.entity.Category;
import com.app.entity.Product;
import com.app.exception.CustomException;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao prodDao;

	@Autowired
	private CategoryDao catDao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public ProductDTO addProducts(ProductDTO prod) {
		Category cat = catDao.findById(prod.getCatId()).orElseThrow(() -> new CustomException("cat id invalid"));
		Product newProd = mapper.map(prod, Product.class);
		newProd.setProdCategory(cat);
		return mapper.map(prodDao.save(newProd), ProductDTO.class);
	}

	@Override
	public List<ProductDTO> getAllProducts() {

		return prodDao.findAll()
				.stream()
				.map(p -> mapper.map(p, ProductDTO.class))
				.collect(Collectors.toList());
	}

}
